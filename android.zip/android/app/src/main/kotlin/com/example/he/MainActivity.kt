package com.example.he

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
