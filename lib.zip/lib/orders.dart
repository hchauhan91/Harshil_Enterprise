import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Orders_page extends StatefulWidget {
  const Orders_page({super.key});

  @override
  State<Orders_page> createState() => _Orders_pageState();
}

class _Orders_pageState extends State<Orders_page> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController date = TextEditingController();
  TextEditingController p1 = TextEditingController();
  TextEditingController p2 = TextEditingController();
  TextEditingController p3 = TextEditingController();
  TextEditingController p4 = TextEditingController();
  TextEditingController p5 = TextEditingController();

  void _showSnackBar(BuildContext context) {
    final snackBar = SnackBar(
      content: Text('Order saved'),
      backgroundColor: Colors.green,
      duration: Duration(seconds: 2),
    );

    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Center(
        child: Text(
          'Orders',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ),
        ),
      )),
      body: Stack(
        children: <Widget>[
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('asset/Back1.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            child: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.all(30),
                child: Column(
                  children: [
                    Text(
                      'Customer Details',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          decoration: TextDecoration.underline),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: name,
                      decoration: InputDecoration(
                          labelText: "Name",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: email,
                      decoration: InputDecoration(
                          labelText: "Email",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: address,
                      decoration: InputDecoration(
                          labelText: "Address",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: phone,
                      decoration: InputDecoration(
                          labelText: "Phone",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: date,
                      decoration: InputDecoration(
                          labelText: "Date",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                      onTap: () async {
                        DateTime? datepicked = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(3000));

                        if (datepicked != null) {
                          setState(() {
                            date.text =
                                DateFormat('dd-MM-yyyy').format(datepicked);
                          });
                        }
                      },
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      'Product Details',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          decoration: TextDecoration.underline),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: p1,
                      decoration: InputDecoration(
                          labelText: "BH-MEDIUM",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: p2,
                      decoration: InputDecoration(
                          labelText: "BH-1",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: p3,
                      decoration: InputDecoration(
                          labelText: "H0-1",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: p4,
                      decoration: InputDecoration(
                          labelText: "H3-1",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    TextField(
                      style: TextStyle(color: Colors.white),
                      controller: p5,
                      decoration: InputDecoration(
                          labelText: "HS-SMALL",
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          )),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    ElevatedButton(
                        onPressed: () async {
                          DatabaseReference reference =
                              FirebaseDatabase.instance.ref(
                                  'Admin/Order_Details/${date.text}/${name.text}');
                          await reference.set({
                            "name": name.text,
                            "email": email.text,
                            "address": address.text,
                            "phone": phone.text,
                            "BH-MEDIUM": p1.text,
                            "BH-1": p2.text,
                            "H0-1": p3.text,
                            "H3-1": p4.text,
                            "HS-SMALL": p5.text,
                          });
                          _showSnackBar(context);
                        },
                        child: Text('Save Order'))
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
