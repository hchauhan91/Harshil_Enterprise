//import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class AttendanceListPage extends StatefulWidget {
  final String date;
  final List<String> names;
  final List<bool> attendanceList;

  AttendanceListPage(this.date, this.names, this.attendanceList);

  @override
  State<AttendanceListPage> createState() => _AttendanceListPageState();
}

class _AttendanceListPageState extends State<AttendanceListPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Details'),
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          image: DecorationImage(
            image:
                AssetImage('asset/Back1.jpg'), // Replace with your image asset
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(
          children: List.generate(widget.attendanceList.length, (index) {
            int number = index + 1;
            return Card(
              margin: EdgeInsets.all(10),
              child: ListTile(
                tileColor: Colors.grey,
                title: Text(
                  '$number. ${widget.names[index]}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                trailing: Text(
                  widget.attendanceList[index] ? "Present" : "Absent",
                  style: TextStyle(fontSize: 16),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
