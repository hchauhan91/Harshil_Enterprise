import 'package:flutter/material.dart';
import 'attendance.dart';
import 'orders.dart';
import 'graph.dart';
import 'stocks.dart';

class Page2 extends StatefulWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  State<Page2> createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {},
        ),
        title: const Text(
          'Harshil Enterprise',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Stack(
        children: [
          Image.asset(
            'asset/Back1.jpg',
            filterQuality: FilterQuality.high,
            width: double.infinity,
            height: double.infinity,
            fit: BoxFit.cover,
          ),
          LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth > 600) {
                // Desktop layout
                return Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: 600),
                    child: Column(
                      children: [
                        SizedBox(height: 30),
                        _buildGridItem(
                          context,
                          Icons.person,
                          'Attendance',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => AttendancePage(),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 30),
                        _buildGridItem(
                          context,
                          Icons.trending_up,
                          'Orders',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Orders_page(),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 30),
                        _buildGridItem(
                          context,
                          Icons.import_export,
                          'Production and Selling',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Stocks_page(),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 30),
                        _buildGridItem(
                          context,
                          Icons.show_chart,
                          'Graph',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => GraphPage(),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                );
              } else {
                // Mobile layout
                return Center(
                  child: Column(
                    children: [
                      SizedBox(height: 30),
                      _buildGridItem(
                        context,
                        Icons.person,
                        'Attendance',
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AttendancePage(),
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 30),
                      _buildGridItem(
                        context,
                        Icons.trending_up,
                        'Orders',
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Orders_page(),
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 30),
                      _buildGridItem(
                        context,
                        Icons.import_export,
                        'Production and Selling',
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => Stocks_page(),
                            ),
                          );
                        },
                      ),
                      SizedBox(height: 30),
                      _buildGridItem(
                        context,
                        Icons.show_chart,
                        'Graph',
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => GraphPage(),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildGridItem(
    BuildContext context,
    IconData iconData,
    String label,
    VoidCallback onPressed,
  ) {
    return Column(
      children: [
        Ink(
          decoration: ShapeDecoration(
            color: Colors.blue,
            shape: CircleBorder(),
          ),
          child: InkWell(
            onTap: onPressed,
            child: Icon(
              iconData,
              size: 80.0,
              color: Colors.white,
            ),
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 18.0,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}
