import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
//import 'package:firebase_database/firebase_database.dart';
import 'attendance_list.dart';

class AttendancePage extends StatefulWidget {
  @override
  _AttendancePageState createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  List<bool> attendanceList = List.generate(25, (index) => false);
  String selectedDate = "Select a Date";
  final DatabaseReference _databaseReference =
      FirebaseDatabase.instance.reference();

  void openDatePicker() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (picked != null && picked != DateTime.now()) {
      setState(() {
        selectedDate = "${picked.day}/${picked.month}/${picked.year}";
      });
    }
  }

  void saveAttendance() {
    List<String> names = [
      'Alpesh Teraiya',
      'Avinash Raviya',
      'Aakash Joshi',
      'Bipin Boricha',
      'Bharat Jadav',
      'Dilip Makwana',
      'Dushyant Doshi',
      'Dipak Pala',
      'Faizan Hokayat',
      'Girish Majithiya',
      'Hitesh Kanjariya',
      'Hiten Jethva',
      'Jatin Sakariya',
      'Kishan Lathiya',
      'Lalit Vadoliya',
      'Manish Vyas',
      'Mohit Parmar',
      'Mehul Dangar',
      'Nilesh Parmar',
      'Pradhyumansinh Gohil',
      'Piyush Rathod',
      'Rajesh Pandya',
      'Shailesh Ghataliya',
      'Tarun Goswami',
      'Zakir Para',
    ];
    final String formattedDate =
        "${selectedDate.split('/')[0]}-${selectedDate.split('/')[1]}-${selectedDate.split('/')[2]}";

    final Map<String, dynamic> presentData = {};
    final Map<String, dynamic> absentData = {};

    for (int index = 0; index < attendanceList.length; index++) {
      final String name = names[index];
      if (attendanceList[index]) {
        presentData[name] = true;
      } else {
        absentData[name] = true;
      }
    }

    _databaseReference
        .child('Admin/Attendance_List/$formattedDate/Present')
        .set(presentData);
    _databaseReference
        .child('Admin/Attendance_List/$formattedDate/Absent')
        .set(absentData);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Attendance data saved!'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<String> names = [
      'Alpesh Teraiya',
      'Avinash Raviya',
      'Aakash Joshi',
      'Bipin Boricha',
      'Bharat Jadav',
      'Dilip Makwana',
      'Dushyant Doshi',
      'Dipak Pala',
      'Faizan Hokayat',
      'Girish Majithiya',
      'Hitesh Kanjariya',
      'Hiten Jethva',
      'Jatin Sakariya',
      'Kishan Lathiya',
      'Lalit Vadoliya',
      'Manish Vyas',
      'Mohit Parmar',
      'Mehul Dangar',
      'Nilesh Parmar',
      'Pradhyumansinh Gohil',
      'Piyush Rathod',
      'Rajesh Pandya',
      'Shailesh Ghataliya',
      'Tarun Goswami',
      'Zakir Para',
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Page'),
      ),
      body: Container(
        padding: const EdgeInsets.all(1),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                'asset/Back1.jpg'), // Replace 'background.jpg' with your image asset.
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: <Widget>[
            ListTile(
              contentPadding: EdgeInsets.all(2),
              title: Text(
                'Selected Date: $selectedDate',
                style: TextStyle(color: Colors.white),
              ),
              onTap: openDatePicker,
            ),
            Expanded(
              child: ListView.builder(
                itemCount: attendanceList.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      '${names[index]}',
                      style: TextStyle(color: Colors.white),
                    ),
                    trailing: InkWell(
                      onTap: () {
                        setState(() {
                          attendanceList[index] = !attendanceList[index];
                        });
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: attendanceList[index]
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(0),
                          child: attendanceList[index]
                              ? Icon(
                                  Icons.check,
                                  color: Colors.white,
                                )
                              : Icon(
                                  Icons.check_box_outline_blank,
                                  color: Colors.white,
                                ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        AttendanceListPage(selectedDate, names, attendanceList),
                  ),
                );
              },
              child: Text('View Attendance'),
            ),
            SizedBox(
              height: 10,
            ),
            ElevatedButton(
                onPressed: () {
                  saveAttendance();
                },
                child: Text('Save Data'))
          ],
        ),
      ),
    );
  }
}
