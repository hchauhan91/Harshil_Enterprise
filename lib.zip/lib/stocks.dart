import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Stocks_page extends StatefulWidget {
  const Stocks_page({super.key});

  @override
  State<Stocks_page> createState() => _Stocks_pageState();
}

class _Stocks_pageState extends State<Stocks_page> {
  TextEditingController sdate = TextEditingController();
  TextEditingController pro1 = TextEditingController();
  TextEditingController pro2 = TextEditingController();
  TextEditingController pro3 = TextEditingController();
  TextEditingController pro4 = TextEditingController();
  TextEditingController pro5 = TextEditingController();
  TextEditingController sls1 = TextEditingController();
  TextEditingController sls2 = TextEditingController();
  TextEditingController sls3 = TextEditingController();
  TextEditingController sls4 = TextEditingController();
  TextEditingController sls5 = TextEditingController();
  int p1 = 0;
  int p2 = 0;
  int p3 = 0;
  int p4 = 0;
  int p5 = 0;
  int s1 = 0;
  int s2 = 0;
  int s3 = 0;
  int s4 = 0;
  int s5 = 0;
  int totalp = 0;
  int totals = 0;

  void _showSnackBar(BuildContext context) {
    final snackBar = SnackBar(
      content: Text('Details saved'),
      backgroundColor: Colors.green,
      duration: Duration(seconds: 2),
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Center(
          child: Text(
            'Stocks',
            style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
        )),
        body: Stack(children: <Widget>[
          // Background image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('asset/Back1.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),

          CustomScrollView(
            primary: false,
            slivers: <Widget>[
              SliverPadding(
                padding: const EdgeInsets.all(15),
                sliver: SliverGrid.count(
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  crossAxisCount: 3,
                  childAspectRatio: 4.0,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.all(8),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: TextField(
                        style: TextStyle(color: Colors.white),
                        controller: sdate,
                        decoration: InputDecoration(
                            labelText: "Date",
                            labelStyle: TextStyle(
                              color: Colors.white,
                            )),
                        onTap: () async {
                          DateTime? datepicked = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(2000),
                              lastDate: DateTime(3000));

                          if (datepicked != null) {
                            setState(() {
                              sdate.text =
                                  DateFormat('dd-MM-yyyy').format(datepicked);
                            });
                          }
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                    ),
                    Container(),
                    Container(),
                    Container(),
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        'PRODUCT',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        'PRODUCTION',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(8),
                      child: const Text(
                        'SALES',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Container(),
                    Container(),
                    Container(),
                    Text(
                      'BH-MEDIUM',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p1 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: pro1,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          s1 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: sls1,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    Text(
                      'BH-1',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p2 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: pro2,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p2 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: sls2,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    Text(
                      'H0-1',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p3 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: pro3,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          s3 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: sls3,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    Text(
                      'H3-1',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p4 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: pro4,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          s4 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: sls4,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    Text(
                      'HS-SMALL',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          p5 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: pro5,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    TextField(
                      onChanged: (text) {
                        setState(() {
                          s5 = int.parse(text);
                        });
                      },
                      style: TextStyle(color: Colors.white),
                      controller: sls5,
                      decoration: InputDecoration(
                          labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      )),
                    ),
                    Container(),
                    Text(
                      '${totalp}',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      '${totals}',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                    Container(),
                    Container(),
                    Container(),
                    Container(),
                    ElevatedButton(
                        onPressed: () {
                          totalp = p1 + p2 + p3 + p4 + p5;
                          totals = s1 + s2 + s3 + s4 + s5;
                          setState(() {});
                        },
                        child: Text('Display Total')),
                    Container(),
                    Container(),
                    ElevatedButton(
                        onPressed: () async {
                          DatabaseReference refpro = FirebaseDatabase.instance
                              .ref(
                                  'Admin/Stock_Details/${sdate.text}/production');
                          await refpro.set({
                            "BH-MEDIUM": pro1.text,
                            "BH-1": pro2.text,
                            "H0-1": pro3.text,
                            "H3-1": pro4.text,
                            "HS-SMALL": pro5.text,
                            "Total-Production": totalp,
                          });
                          DatabaseReference refsell = FirebaseDatabase.instance
                              .ref('Admin/Stock_Details/${sdate.text}/Sales');
                          await refsell.set({
                            "BH-MEDIUM": sls1.text,
                            "BH-1": sls2.text,
                            "H0-1": sls3.text,
                            "H3-1": sls4.text,
                            "HS-SMALL": sls5.text,
                            "Total-Sells": totals,
                          });
                          _showSnackBar(context);
                        },
                        child: Text('Save Stocks')),
                    Container()
                  ],
                ),
              ),
            ],
          )
        ]));
  }
}
