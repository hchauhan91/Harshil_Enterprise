import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

class GraphPage extends StatefulWidget {
  late final String selectedDate;

  //GraphPage({required this.selectedDate});

  @override
  _GraphPageState createState() => _GraphPageState();
}

class _GraphPageState extends State<GraphPage> {
  List<DataPoint> dataPoints = [];

  @override
  void initState() {
    super.initState();
    Firebase.initializeApp();
    fetchData();
  }

  void fetchData() async {
    DatabaseReference _databaseReference = FirebaseDatabase().reference();

    try {
      DataSnapshot snapshot = await _databaseReference
          .child('Admin/Stock_Details/${widget.selectedDate}')
          .once() as DataSnapshot;
      Map<dynamic, dynamic>? data = snapshot.value as Map<dynamic, dynamic>?;

      if (data != null) {
        data.forEach((date, values) {
          if (values is Map<dynamic, dynamic> &&
              values.containsKey('production') &&
              values.containsKey('Sales')) {
            int totalp = values['production']['Total-Production'];
            int totals = values['Sales']['Total-Sells'];

            dataPoints.add(DataPoint(date, totalp, totals));
          }
        });
        setState(() {});
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Line Graph'),
      ),
      body: Center(
        child: LineChart(
          LineChartData(
            gridData: FlGridData(show: false),
            titlesData: FlTitlesData(show: false),
            borderData: FlBorderData(show: false),
            minX: 0,
            maxX: dataPoints.length.toDouble(),
            minY: 0,
            maxY: 1000, // Adjust this based on your data
            lineBarsData: [
              LineChartBarData(
                spots: dataPoints.asMap().entries.map((entry) {
                  return FlSpot(
                      entry.key.toDouble(), entry.value.totalp.toDouble());
                }).toList(),
                isCurved: true,
                color: Colors.blue,
                barWidth: 4,
                isStrokeCapRound: true,
                belowBarData: BarAreaData(show: false),
              ),
              LineChartBarData(
                spots: dataPoints.asMap().entries.map((entry) {
                  return FlSpot(
                      entry.key.toDouble(), entry.value.totals.toDouble());
                }).toList(),
                isCurved: true,
                color: Colors.green,
                barWidth: 4,
                isStrokeCapRound: true,
                belowBarData: BarAreaData(show: false),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DataPoint {
  final String date;
  final int totalp;
  final int totals;

  DataPoint(this.date, this.totalp, this.totals);
}
